Problem staement :Create a Python script or workflow that automates the analysis of customer data (e.g., purchase history, browsing behavior) to identify trends and segment customers for targeted marketing campaigns. What data processing and visualization tools would you use? 

Here are the steps to implement the customer segmentation analysis:

Step 1: Data Ingestion

Collect the customer data from a database or CSV file.
Use pandas to read the data into a DataFrame.

Step 2: Data Cleaning

a. Handle missing values by imputing them with the mean or median value.
b. Encode categorical variables using pandas' Categorical function.
c. Scale/normalize numerical variables using scikit-learn's StandardScaler.

Step 3: Exploratory Data Analysis (EDA)

Use matplotlib and seaborn to produce visuals to gain insights on distributions of customer data.

Step 4: Clustering

Use scikit-learn's KMeans to perform clustering analysis.

Step 5: Segmentation

Use pandas to group the data by cluster and analyze the segments.


Step 6: Visualization

Use Plotly to create an interactive visualization of the customer segments.



This script uses the following tools:

Pandas: for data ingestion, cleaning, and manipulation.
Matplotlib and Seaborn: for exploratory data analysis (EDA) and visualization.
Scikit-learn: for clustering analysis (k-means) and evaluation (silhouette score).
Plotly: for interactive visualization of customer segments.


```python
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objs as go
from sklearn.preprocessing import LabelEncoder, StandardScaler

import warnings
warnings.filterwarnings("ignore", category=UserWarning, module='sklearn')
```


```python
df = pd.read_csv('Booksheet.csv')

```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Category</th>
      <th>Purchase History</th>
      <th>Browsing Behavior</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Electronics</td>
      <td>500</td>
      <td>High</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Fashion</td>
      <td>200</td>
      <td>Medium</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Electronics</td>
      <td>800</td>
      <td>High</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Fashion</td>
      <td>400</td>
      <td>Low</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Electronics</td>
      <td>300</td>
      <td>Medium</td>
    </tr>
  </tbody>
</table>
</div>



Data processing and outliners


```python
df = pd.get_dummies(df, columns=['Category'])
df['Purchase History'] = pd.to_numeric(df['Purchase History'])
```


```python
df.info
```




    <bound method DataFrame.info of     Customer ID  Purchase History Browsing Behavior  Category_Electronics  \
    0             1               500              High                  True   
    1             2               200            Medium                 False   
    2             3               800              High                  True   
    3             4               400               Low                 False   
    4             5               300            Medium                  True   
    ..          ...               ...               ...                   ...   
    95           96               700            Medium                 False   
    96           97               400            Medium                  True   
    97           98               200               Low                 False   
    98           99               600              High                  True   
    99          100               500            Medium                 False   
    
        Category_Fashion  
    0              False  
    1               True  
    2              False  
    3               True  
    4              False  
    ..               ...  
    95              True  
    96             False  
    97              True  
    98             False  
    99              True  
    
    [100 rows x 5 columns]>



Step 2: Data Cleaning

Handle missing values by imputing them with the mean or median value.



```python
import pandas as pd


df = pd.read_csv('Booksheet.csv')


numeric_cols = df.select_dtypes(include=['int64', 'float64']).columns

df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean(axis=0))

```

Encode categorical variables using pandas' Categorical function.


```python
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler


categorical_cols = df.select_dtypes(include=['object']).columns

le = LabelEncoder()
df[categorical_cols] = df[categorical_cols].apply(le.fit_transform)


numeric_cols = df.select_dtypes(include=['int64', 'float64']).columns


df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())


scaler = StandardScaler()
df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

```

Scale/normalize numerical variables using scikit-learn's StandardScaler.


```python
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
df[['Purchase History', 'Browsing Behavior']] = scaler.fit_transform(df[['Purchase History', 'Browsing Behavior']])
```


```python
df.info
```




    <bound method DataFrame.info of     Customer ID  Category  Purchase History  Browsing Behavior
    0     -1.714816         0         -0.176432          -1.212626
    1     -1.680173         1         -1.499676           0.972286
    2     -1.645531         0          1.146811          -1.212626
    3     -1.610888         1         -0.617514          -0.120170
    4     -1.576245         0         -1.058595           0.972286
    ..          ...       ...               ...                ...
    95     1.576245         1          0.705730           0.972286
    96     1.610888         0         -0.617514           0.972286
    97     1.645531         1         -1.499676          -0.120170
    98     1.680173         0          0.264649          -1.212626
    99     1.714816         1         -0.176432           0.972286
    
    [100 rows x 4 columns]>



Step 3: Exploratory Data Analysis (EDA)

Use matplotlib and seaborn to produce visuals to gain insights on distributions of customer data.


```python
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(10, 6))
sns.histplot(df['Purchase History'], kde=False)
plt.title('Distribution of Scaled Purchase History')
plt.show()

plt.figure(figsize=(10, 6))
sns.histplot(df['Browsing Behavior'], kde=False)
plt.title('Distribution of Scaled Browsing Behavior')
plt.show()
```


    
![png](output_17_0.png)
    



    
![png](output_17_1.png)
    



```python

# EDA
plt.figure(figsize=(10, 5))
sns.boxplot(df['Purchase History'])
plt.title('Distribution of Purchase History')
plt.show()

```


    
![png](output_18_0.png)
    



```python

```


```python
sns.scatterplot(x = df['Purchase History'], y = df['Browsing Behavior'],color = 'grey')
```




    <Axes: xlabel='Purchase History', ylabel='Browsing Behavior'>




    
![png](output_20_1.png)
    



```python
import os
os.environ['OMP_NUM_THREADS'] = '1'
# Clustering
kmeans = KMeans(n_clusters=5, random_state=42)
kmeans.fit(df[['Purchase History', 'Browsing Behavior']])
labels = kmeans.labels_

```


```python
segments = pd.DataFrame({'segment': labels, 'Purchase History': df['Purchase History'], 'Browsing Behavior': df['Browsing Behavior']})
```


```python
# Visualization
fig = go.Figure(data=[go.Scatter(x=segments['Purchase History'], y=segments['Browsing Behavior'], mode='markers', marker=dict(color=segments['segment']))])
fig.update_layout(title='Customer Segments', xaxis_title='Purchase History', yaxis_title='Browsing Behavior')
fig.show()
```


<div>                            <div id="1bf0ce05-efbb-4462-a70a-561f9307ba87" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("1bf0ce05-efbb-4462-a70a-561f9307ba87")) {                    Plotly.newPlot(                        "1bf0ce05-efbb-4462-a70a-561f9307ba87",                        [{"marker":{"color":[2,0,3,4,2,0,1,0,2,3,1,3,2,0,2,1,3,2,1,0,2,3,4,3,3,3,2,0,2,1,4,1,1,0,2,1,4,0,4,4,3,1,3,0,2,0,3,0,4,4,0,4,4,0,3,1,0,2,0,0,4,3,1,0,0,2,3,1,4,0,3,3,3,1,3,0,4,4,0,3,4,1,3,3,1,2,4,0,0,1,3,2,0,0,0,1,2,3,4,0]},"mode":"markers","x":[0.773277607002822,-1.267434820265117,-0.825094603789917,-0.3753200979621928,1.2973950063557897,-1.4049691732868177,0.7955804750603951,-1.0927290204807942,1.646806605924435,-0.9105889313439472,1.565029423046667,-1.048123284365648,0.873640513261901,-0.7358831315596246,1.3605864658522469,1.0929520491613698,-0.19318000882534578,1.5910494357805023,0.5019260456356825,-0.4459458468111743,0.5799860838371884,-0.9514775227828313,0.9293976834058336,0.08560584189431798,-1.2265462288262328,-0.8473974718474901,0.672914700743743,-0.6280859359480213,1.6951294867158435,0.9851548535497664,-0.49426872760258267,1.4535150827588015,1.6207865931905998,-0.14113998335767522,0.6877832794487917,0.47962317757810946,-0.2117657322066567,-0.8325288931424414,-0.15600856206272395,0.32350310117509773,-0.20433144285413232,0.4833403222543716,-0.15600856206272395,-1.49418064551711,1.018609155636126,-1.0964461651570563,-0.17831143012029704,-1.2153947947974462,0.5539660711033532,1.1487092193053026,-1.1224661778908918,0.6283089646285968,1.1672949426866135,-1.0295375609843371,-0.8027917357323439,0.5093603349882069,-0.05192851112738281,1.3271321637658873,-1.4272720413443907,-1.3640805818479336,1.040912023693699,-1.4458577647257016,1.3122635850608386,-1.2600005309125926,-1.4198377519918663,1.6616751846294837,-1.5387863816322562,1.282526427650741,-0.4385115574586499,-1.2823033989701655,-1.4607263434307505,-0.9031546419914228,-1.1038804545095808,1.4163436359961796,-0.5574601870990398,-0.9328917994015203,0.47962317757810946,-0.20061429817787016,-0.8957203526388985,0.07073726318926925,0.23429162894480532,0.6097232412472858,-0.5165715956601558,-0.5388744637177288,0.7881461857078707,1.282526427650741,0.3346545352038843,-1.230263373502495,-0.7396002762358868,1.6728266186582703,-0.5797630551566129,1.6914123420395812,-0.4794001488975339,-0.360451519257144,-1.5090492242221587,0.6766318454200052,1.542726554989094,-0.05564565580364499,0.09304013124684235,-0.6578230933581187],"y":[-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-0.08220516160604883,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,1.0921542899089336,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,1.0921542899089336,-0.08220516160604883,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-0.08220516160604883,1.0921542899089336,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-0.08220516160604883,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-0.08220516160604883,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,1.0921542899089336,1.0921542899089336,1.0921542899089336,-0.08220516160604883,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,-0.08220516160604883,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,-0.08220516160604883,1.0921542899089336,1.0921542899089336,-0.08220516160604883,-1.2565646131210313,1.0921542899089336,1.0921542899089336,1.0921542899089336,1.0921542899089336,1.0921542899089336,-0.08220516160604883,-0.08220516160604883,-0.08220516160604883,-1.2565646131210313,1.0921542899089336,-0.08220516160604883,1.0921542899089336,1.0921542899089336,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,-1.2565646131210313,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,-1.2565646131210313,-0.08220516160604883,1.0921542899089336,-0.08220516160604883,1.0921542899089336,-0.08220516160604883,-1.2565646131210313],"type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"title":{"text":"Customer Segments"},"xaxis":{"title":{"text":"Purchase History"}},"yaxis":{"title":{"text":"Browsing Behavior"}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('1bf0ce05-efbb-4462-a70a-561f9307ba87');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
plot purchase vs broesing VS category
```


```python
import pandas as pd
import plotly.express as px
from sklearn.preprocessing import StandardScaler, LabelEncoder
import numpy as np

# Generate 100 random data points
np.random.seed(0)
data = {
    "Customer ID": np.arange(1, 101),
    "Category": np.random.choice(["Electronics", "Fashion"], size=100),
    "Purchase History": np.random.randint(100, 1000, size=100),
    "Browsing Behavior": np.random.choice(["High", "Medium", "Low"], size=100)
}

df = pd.DataFrame(data)

# Encode the categorical values in the 'Browsing Behavior' column
le = LabelEncoder()
df['Browsing Behavior'] = le.fit_transform(df['Browsing Behavior'])

# Apply StandardScaler to the 'Purchase History' and 'Browsing Behavior' columns
scaler = StandardScaler()
df[['Purchase History', 'Browsing Behavior']] = scaler.fit_transform(df[['Purchase History', 'Browsing Behavior']])

# Create a numerical representation of 'Category'
df['Category_Numeric'] = df['Category'].map({'Electronics': 0, 'Fashion': 1})

# Plot the scaled data
fig = px.scatter_3d(df, x="Purchase History", y="Browsing Behavior", z="Category_Numeric", color="Category")
fig.update_layout(
    title="Purchase History vs Browsing Behavior vs Category",
    scene = dict(
        xaxis_title="Purchase History",
        yaxis_title="Browsing Behavior",
        zaxis_title="Category"),
    font=dict(
        family="Arial",
        size=14,
        color="#ffffff"
    ),
    plot_bgcolor="#f0f0f0", 
    paper_bgcolor="#000000",
    xaxis_showgrid=True,
    yaxis_showgrid=True,
    xaxis_gridcolor="#fff000", 
    yaxis_gridcolor="#000fff"
)

# Show the graph
fig.show()
```


<div>                            <div id="a644e632-dd4b-43da-a148-b9edd5cdc52e" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("a644e632-dd4b-43da-a148-b9edd5cdc52e")) {                    Plotly.newPlot(                        "a644e632-dd4b-43da-a148-b9edd5cdc52e",                        [{"hovertemplate":"Category=Electronics\u003cbr\u003ePurchase History=%{x}\u003cbr\u003eBrowsing Behavior=%{y}\u003cbr\u003eCategory_Numeric=%{z}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Electronics","marker":{"color":"#636efa","symbol":"circle"},"mode":"markers","name":"Electronics","scene":"scene","showlegend":true,"x":[0.773277607002822,-0.3753200979621928,-1.048123284365648,0.873640513261901,1.3605864658522469,1.0929520491613698,-0.19318000882534578,1.5910494357805023,0.5019260456356825,0.5799860838371884,0.08560584189431798,-1.2265462288262328,0.9851548535497664,1.4535150827588015,-0.14113998335767522,-0.2117657322066567,0.32350310117509773,-0.20433144285413232,-0.15600856206272395,0.5539660711033532,-1.1224661778908918,0.5093603349882069,1.3271321637658873,-1.4272720413443907,-1.4458577647257016,-1.2600005309125926,1.6616751846294837,-1.5387863816322562,1.282526427650741,-0.4385115574586499,-1.2823033989701655,-1.1038804545095808,1.4163436359961796,-0.5574601870990398,-0.20061429817787016,0.07073726318926925,0.23429162894480532,-0.5165715956601558,1.6728266186582703,-0.4794001488975339,-0.360451519257144,0.6766318454200052,1.542726554989094,-0.6578230933581187],"y":[-1.2565646131210313,-0.08220516160604883,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,1.0921542899089336,-0.08220516160604883,1.0921542899089336,-1.2565646131210313,1.0921542899089336,1.0921542899089336,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,1.0921542899089336,1.0921542899089336,-0.08220516160604883,-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,1.0921542899089336,1.0921542899089336,-0.08220516160604883,-1.2565646131210313,1.0921542899089336,1.0921542899089336,1.0921542899089336,-0.08220516160604883,1.0921542899089336,-0.08220516160604883,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-0.08220516160604883,-1.2565646131210313],"z":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"type":"scatter3d"},{"hovertemplate":"Category=Fashion\u003cbr\u003ePurchase History=%{x}\u003cbr\u003eBrowsing Behavior=%{y}\u003cbr\u003eCategory_Numeric=%{z}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Fashion","marker":{"color":"#EF553B","symbol":"circle"},"mode":"markers","name":"Fashion","scene":"scene","showlegend":true,"x":[-1.267434820265117,-0.825094603789917,1.2973950063557897,-1.4049691732868177,0.7955804750603951,-1.0927290204807942,1.646806605924435,-0.9105889313439472,1.565029423046667,-0.7358831315596246,-0.4459458468111743,-0.9514775227828313,0.9293976834058336,-0.8473974718474901,0.672914700743743,-0.6280859359480213,1.6951294867158435,-0.49426872760258267,1.6207865931905998,0.6877832794487917,0.47962317757810946,-0.8325288931424414,-0.15600856206272395,0.4833403222543716,-1.49418064551711,1.018609155636126,-1.0964461651570563,-0.17831143012029704,-1.2153947947974462,1.1487092193053026,0.6283089646285968,1.1672949426866135,-1.0295375609843371,-0.8027917357323439,-0.05192851112738281,-1.3640805818479336,1.040912023693699,1.3122635850608386,-1.4198377519918663,-1.4607263434307505,-0.9031546419914228,-0.9328917994015203,0.47962317757810946,-0.8957203526388985,0.6097232412472858,-0.5388744637177288,0.7881461857078707,1.282526427650741,0.3346545352038843,-1.230263373502495,-0.7396002762358868,-0.5797630551566129,1.6914123420395812,-1.5090492242221587,-0.05564565580364499,0.09304013124684235],"y":[-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-0.08220516160604883,1.0921542899089336,-1.2565646131210313,-1.2565646131210313,-1.2565646131210313,-0.08220516160604883,1.0921542899089336,-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,1.0921542899089336,-0.08220516160604883,-1.2565646131210313,-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,-0.08220516160604883,-0.08220516160604883,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,1.0921542899089336,-1.2565646131210313,1.0921542899089336,1.0921542899089336,-0.08220516160604883,-0.08220516160604883,-1.2565646131210313,1.0921542899089336,1.0921542899089336,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,-0.08220516160604883,-1.2565646131210313,1.0921542899089336,-1.2565646131210313,-0.08220516160604883,1.0921542899089336,-0.08220516160604883],"z":[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],"type":"scatter3d"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"scene":{"domain":{"x":[0.0,1.0],"y":[0.0,1.0]},"xaxis":{"title":{"text":"Purchase History"}},"yaxis":{"title":{"text":"Browsing Behavior"}},"zaxis":{"title":{"text":"Category"}}},"legend":{"title":{"text":"Category"},"tracegroupgap":0},"margin":{"t":60},"font":{"family":"Arial","size":14,"color":"#ffffff"},"xaxis":{"showgrid":true,"gridcolor":"#fff000"},"yaxis":{"showgrid":true,"gridcolor":"#000fff"},"title":{"text":"Purchase History vs Browsing Behavior vs Category"},"plot_bgcolor":"#f0f0f0","paper_bgcolor":"#000000"},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('a644e632-dd4b-43da-a148-b9edd5cdc52e');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
plt.figure(figsize = (15, 5))
fig = plt.plot(df['Category'], df[['Purchase History', 'Browsing Behavior']])
plt.grid();
```


    
![png](output_26_0.png)
    


CORRELATION


```python
df = pd.get_dummies(df, columns=['Category'])
```


```python
corr = df.corr()
sns.heatmap(data=corr)
```




    <Axes: >




    
![png](output_29_1.png)
    


Step 4: Clustering

Use scikit-learn's KMeans to perform clustering analysis.


```python
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

kmeans = KMeans(n_clusters=5)
df['cluster'] = kmeans.fit_predict(df[['Purchase History', 'Browsing Behavior']])
```

Evaluate the clustering using the silhouette score


```python
silhouette = silhouette_score(df[['Purchase History', 'Browsing Behavior']], df['cluster'])
print(f'Silhouette Score: {silhouette:.3f}')
```

    Silhouette Score: 0.737
    

Step 5: Segmentation

Use pandas to group the data by cluster and analyze the segments.


```python
segments = df.groupby('cluster')
for name, group in segments:
    print(f'Segment {name}:')
    print(group.describe())
```

    Segment 0:
           Customer ID   Category  Purchase History  Browsing Behavior  cluster
    count    13.000000  13.000000         13.000000       1.300000e+01     13.0
    mean     -0.174546   0.153846         -1.126453       9.722857e-01      0.0
    std       1.053582   0.375534          0.165641       1.155557e-16      0.0
    min      -1.680173   0.000000         -1.499676       9.722857e-01      0.0
    25%      -1.021961   0.000000         -1.058595       9.722857e-01      0.0
    50%      -0.190535   0.000000         -1.058595       9.722857e-01      0.0
    75%       0.640891   0.000000         -1.058595       9.722857e-01      0.0
    max       1.472317   1.000000         -1.058595       9.722857e-01      0.0
    Segment 1:
           Customer ID   Category  Purchase History  Browsing Behavior  cluster
    count    37.000000  37.000000         37.000000          37.000000     37.0
    mean     -0.007022   0.324324          0.932231          -1.212626      1.0
    std       1.017003   0.474579          0.584621           0.000000      0.0
    min      -1.714816   0.000000         -0.176432          -1.212626      1.0
    25%      -0.814105   0.000000          0.264649          -1.212626      1.0
    50%       0.017321   0.000000          1.146811          -1.212626      1.0
    75%       0.848747   1.000000          1.587892          -1.212626      1.0
    max       1.680173   1.000000          1.587892          -1.212626      1.0
    Segment 2:
           Customer ID   Category  Purchase History  Browsing Behavior  cluster
    count    23.000000  23.000000         23.000000       2.300000e+01     23.0
    mean      0.193548   0.478261         -0.368207       9.722857e-01      2.0
    std       0.963446   0.510754          0.223571       2.270350e-16      0.0
    min      -1.403031   0.000000         -0.617514       9.722857e-01      2.0
    25%      -0.554284   0.000000         -0.617514       9.722857e-01      2.0
    50%       0.225178   0.000000         -0.176432       9.722857e-01      2.0
    75%       0.969997   1.000000         -0.176432       9.722857e-01      2.0
    max       1.714816   1.000000         -0.176432       9.722857e-01      2.0
    Segment 3:
           Customer ID  Category  Purchase History  Browsing Behavior  cluster
    count    15.000000      15.0         15.000000       1.500000e+01     15.0
    mean     -0.169749       1.0         -1.323243      -1.201701e-01      3.0
    std       1.078211       0.0          0.401498       4.309463e-17      0.0
    min      -1.610888       1.0         -1.940757      -1.201701e-01      3.0
    25%      -1.056604       1.0         -1.499676      -1.201701e-01      3.0
    50%      -0.294463       1.0         -1.499676      -1.201701e-01      3.0
    75%       0.675534       1.0         -1.279135      -1.201701e-01      3.0
    max       1.645531       1.0         -0.617514      -1.201701e-01      3.0
    Segment 4:
           Customer ID   Category  Purchase History  Browsing Behavior  cluster
    count    12.000000  12.000000      1.200000e+01       1.200000e+01     12.0
    mean      0.051964   0.833333      7.057297e-01       9.722857e-01      4.0
    std       1.001104   0.389249      2.319180e-16       1.159590e-16      0.0
    min      -1.506960   0.000000      7.057297e-01       9.722857e-01      4.0
    25%      -0.701516   1.000000      7.057297e-01       9.722857e-01      4.0
    50%       0.051964   1.000000      7.057297e-01       9.722857e-01      4.0
    75%       0.814105   1.000000      7.057297e-01       9.722857e-01      4.0
    max       1.576245   1.000000      7.057297e-01       9.722857e-01      4.0
    

Step 6: Visualization

Use Plotly to create an interactive visualization of the customer segments.
Used above also.




```python
plt.figure(figsize = (15, 5))
fig = plt.plot(df['Category'], df[['Purchase History', 'Browsing Behavior']])
plt.grid();
```


    
![png](output_37_0.png)
    



```python

sns.pairplot(df, vars=['Category', 'Purchase History', 'Browsing Behavior','cluster'], hue='Customer ID')
plt.show()
```


    
![png](output_38_0.png)
    



```python
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Assuming your data is in a Pandas DataFrame called `df`

# Create a new column for the cluster labels
df['Cluster'] = [0]*13 + [1]*37 + [2]*23 + [3]*15 + [4]*12

# Create a rectangular plot
plt.figure(figsize=(10,6))
sns.boxplot(x="Cluster", y="Purchase History", data=df)
plt.title("Purchase History by Cluster")
plt.xlabel("Cluster")
plt.ylabel("Purchase History")
plt.show()

plt.figure(figsize=(10,6))
sns.boxplot(x="Cluster", y="Browsing Behavior", data=df)
plt.title("Browsing Behavior by Cluster")
plt.xlabel("Cluster")
plt.ylabel("Browsing Behavior")
plt.show()

plt.figure(figsize=(10,6))
sns.boxplot(x="Cluster", y="Category", data=df)
plt.title("Category by Cluster")
plt.xlabel("Cluster")
plt.ylabel("Category")
plt.show()
```


    
![png](output_39_0.png)
    



    
![png](output_39_1.png)
    



    
![png](output_39_2.png)
    



```python
import plotly.express as px
import pandas as pd

# Assuming your data is in a Pandas DataFrame called `df`

# Create a new column for the cluster labels
df['Cluster'] = [0]*13 + [1]*37 + [2]*23 + [3]*15 + [4]*12

# Create a 3D scatter plot
fig = px.scatter_3d(df, x="Purchase History", y="Browsing Behavior", z="Category", color="Cluster")
fig.update_layout(
    title="Customer Segments",
    scene = dict(
        xaxis_title="Purchase History",
        yaxis_title="Browsing Behavior",
        zaxis_title="Category"),
    font=dict(
        family="Arial",
        size=14,
        color="#ffffff"
    ),
    plot_bgcolor="#f0f0f0", 
    paper_bgcolor="#000000",
    xaxis_showgrid=True,
    yaxis_showgrid=True,
    xaxis_gridcolor="#fff000", 
    yaxis_gridcolor="#000fff"
)

fig.show()
```


<div>                            <div id="bae64edd-3aba-4559-a576-06925d56a0ae" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("bae64edd-3aba-4559-a576-06925d56a0ae")) {                    Plotly.newPlot(                        "bae64edd-3aba-4559-a576-06925d56a0ae",                        [{"hovertemplate":"Purchase History=%{x}\u003cbr\u003eBrowsing Behavior=%{y}\u003cbr\u003eCategory=%{z}\u003cbr\u003eCluster=%{marker.color}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"","marker":{"color":[0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4],"coloraxis":"coloraxis","symbol":"circle"},"mode":"markers","name":"","scene":"scene","showlegend":false,"x":[-0.17643243655649235,-1.499675710730185,1.1468108376172004,-0.6175135279477232,-1.0585946193389542,0.26464865483473854,0.7057297462259694,-1.9407568021214159,1.5878919290084312,-0.17643243655649235,-0.6175135279477232,-1.0585946193389542,0.26464865483473854,1.1468108376172004,-1.499675710730185,0.7057297462259694,-0.17643243655649235,-0.6175135279477232,1.5878919290084312,0.26464865483473854,-1.0585946193389542,-1.499675710730185,1.1468108376172004,-0.17643243655649235,0.7057297462259694,-0.6175135279477232,0.26464865483473854,-1.0585946193389542,1.5878919290084312,1.1468108376172004,-0.17643243655649235,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235,-1.0585946193389542,1.1468108376172004,1.5878919290084312,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235,-1.0585946193389542,1.1468108376172004,1.5878919290084312,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235,-1.0585946193389542,1.1468108376172004,1.5878919290084312,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235,-1.0585946193389542,1.1468108376172004,1.5878919290084312,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235,-1.0585946193389542,1.1468108376172004,1.5878919290084312,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235,-1.0585946193389542,1.1468108376172004,1.5878919290084312,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235,-1.0585946193389542,1.1468108376172004,1.5878919290084312,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235,-1.0585946193389542,1.1468108376172004,1.5878919290084312,0.7057297462259694,-0.6175135279477232,-1.499675710730185,0.26464865483473854,-0.17643243655649235],"y":[-1.212626021887255,0.9722857292609521,-1.212626021887255,-0.12017014631315139,0.9722857292609521,-1.212626021887255,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,-1.212626021887255,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521,0.9722857292609521,-1.212626021887255,-1.212626021887255,0.9722857292609521,0.9722857292609521,-0.12017014631315139,-1.212626021887255,0.9722857292609521],"z":[0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],"type":"scatter3d"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"scene":{"domain":{"x":[0.0,1.0],"y":[0.0,1.0]},"xaxis":{"title":{"text":"Purchase History"}},"yaxis":{"title":{"text":"Browsing Behavior"}},"zaxis":{"title":{"text":"Category"}}},"coloraxis":{"colorbar":{"title":{"text":"Cluster"}},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"legend":{"tracegroupgap":0},"margin":{"t":60},"font":{"family":"Arial","size":14,"color":"#ffffff"},"xaxis":{"showgrid":true,"gridcolor":"#fff000"},"yaxis":{"showgrid":true,"gridcolor":"#000fff"},"title":{"text":"Customer Segments"},"plot_bgcolor":"#f0f0f0","paper_bgcolor":"#000000"},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('bae64edd-3aba-4559-a576-06925d56a0ae');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def create_cluster_labels(df):
    """Create cluster labels for the customer data"""
    cluster_labels = []
    for i, row in df.iterrows():
        if i < 13:
            cluster_labels.append(0)
        elif i < 50:
            cluster_labels.append(1)
        elif i < 73:
            cluster_labels.append(2)
        elif i < 88:
            cluster_labels.append(3)
        else:
            cluster_labels.append(4)
    return cluster_labels

def create_plots(df, cluster_labels):
    """Create plots for the customer data"""
    fig, axs = plt.subplots(1, 3, figsize=(15, 5))
    sns.boxplot(x=cluster_labels, y="Purchase History", data=df.assign(Cluster=cluster_labels), ax=axs[0])
    axs[0].set_title("Purchase History by Cluster")
    axs[0].set_xlabel("Cluster")
    axs[0].set_ylabel("Purchase History")

    sns.boxplot(x=cluster_labels, y="Browsing Behavior", data=df.assign(Cluster=cluster_labels), ax=axs[1])
    axs[1].set_title("Browsing Behavior by Cluster")
    axs[1].set_xlabel("Cluster")
    axs[1].set_ylabel("Browsing Behavior")

    sns.countplot(x=cluster_labels, hue="Category", data=df.assign(Cluster=cluster_labels), ax=axs[2])
    axs[2].set_title("Category by Cluster")
    axs[2].set_xlabel("Cluster")
    axs[2].set_ylabel("Count")

    plt.tight_layout()
    plt.show()

cluster_labels = create_cluster_labels(df)


create_plots(df, cluster_labels)
```


    
![png](output_41_0.png)
    


Here are some challenges that may be faced:

1. Imbalanced Data: The data is imbalanced, with 50 customers in the "Electronics" category and 50 customers in the "Fashion" category. This imbalance may affect the performance of machine learning models.
2. Limited Features: The data only has four features: Customer ID, Category, Purchase History, and Browsing Behavior. This limited feature set may not capture all the relevant information about the customers.
3. Categorical Variables: The Category and Browsing Behavior features are categorical variables, which may require special handling in machine learning models.
4. Outliers: The Purchase History feature has a wide range of values (from 100 to 900), which may indicate the presence of outliers. These outliers may affect the performance of machine learning models.
5. Lack of Context: The data does not provide any context about the customers, such as their demographics, location, or purchase history over time. This lack of context may make it difficult to understand the underlying patterns in the data.
6. Data Quality Issues: The data may contain errors or inconsistencies, such as missing values or incorrect categorization. These data quality issues may affect the accuracy of machine learning models.
7. Overfitting: The data has a relatively small sample size (100 customers), which may lead to overfitting in machine learning models. Overfitting occurs when a model is too complex and fits the noise in the training data rather than the underlying patterns.
8. Lack of Temporal Information: The data does not provide any temporal information, such as the date of purchase or the time of browsing. This lack of temporal information may make it difficult to understand the dynamics of customer behavior over time.


```python

```

Some potential improvements to the code: 

Use a consistent naming convention: The code uses both camelCase and underscore notation for variable names. It's better to stick to a single convention throughout the code.
1. Use more descriptive variable names: Variable names like df and x are not very descriptive. Consider using more descriptive names like customer_data and purchase_history.
2. Add comments and docstrings: Comments and docstrings can help explain the purpose of the code and make it easier for others to understand.
3. Use functions: The code is a single block of code. Consider breaking it up into smaller functions, each with a specific responsibility. This can make the code more modular and easier to maintain.
4. Use a more robust way to create the cluster labels: The code uses a simple list comprehension to create the cluster labels. Consider using a more robust method, such as using a dictionary to map cluster numbers to labels.
5. Use a more efficient way to create the plots: The code creates three separate plots using matplotlib. Consider using a more efficient method, such as using seaborn to create a single plot with multiple subplots.
6. Add more customization options: The code uses default settings for the plots. Consider adding more customization options, such as allowing the user to specify the plot title, axis labels, and colors.
7. Use a more robust way to handle missing values: The code assumes that there are no missing values in the data. Consider using a more robust method, such as using pandas to handle missing values.


```python

```
